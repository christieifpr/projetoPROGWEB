from django.contrib import admin

from .models import Sigla, Horas, Materia, Atividade, Perfil_professor, Perfil_aluno
# Register your models here.

admin.site.register(Sigla)
admin.site.register(Horas)
admin.site.register(Materia)
admin.site.register(Atividade)
admin.site.register(Perfil_professor)
admin.site.register(Perfil_aluno)



