from os import name
from django.urls import path
from .views import *


urlpatterns = [
    # Criar todos os endereços/rotas
# ATIVIDADE 
    path('cadastrar/atividade/', AtividadeCreate.as_view(), name='cadastrar-atividade'),
    path('editar/atividade/<int:pk>/', AtividadeUpdate.as_view(),name='editar-atividade'),
    path('excluir/atividade/<int:pk>/', AtividadeDelete.as_view(), name='excluir-atividade'),
    path('listar/atividade/', AtividadeList.as_view(), name='listar-atividade'),

# sigla 
    path('cadastrar/sigla/', siglaCreate.as_view(), name='cadastrar-sigla'),
    path('editar/sigla/<int:pk>/', siglaUpdate.as_view(),name='editar-sigla'),
    path('excluir/sigla/<int:pk>/', siglaDelete.as_view(), name='excluir-sigla'),
    path('listar/sigla/', siglaList.as_view(), name='listar-sigla'),

# horas 
    path('cadastrar/horas/', horasCreate.as_view(), name='cadastrar-horas'),
    path('editar/horas/<int:pk>/', horasUpdate.as_view(), name='editar-horas'),
    path('excluir/horas/<int:pk>/', horasDelete.as_view(), name='excluir-horas'),
    path('listar/horas/', horasList.as_view(), name='listar-horas'),

# materia 
    path('cadastrar/materia/', MateriaCreate.as_view(), name='cadastrar-materia'),
    path('editar/materia/<int:pk>/', MateriaUpdate.as_view(), name='editar-materia'),
    path('excluir/materia/<int:pk>/', MateriaDelete.as_view(), name='excluir-materia'),
    path('listar/materia/', MateriaList.as_view(), name='listar-materia'),

# professor 
    path('cadastrar/perfil_prof/', Perfil_professorCreate.as_view(), name='cadastrar-perfil_prof'),
    path('editar/perfil_prof/', Perfil_professorUpdate.as_view(), name='editar-perfil_prof'),
    path('excluir/perfil_prof/<int:pk>/', Perfil_professorDelete.as_view(), name='excluir-perfil_prof'),
    path('listar/perfil_prof/', Perfil_professorList.as_view(), name='listar-perfil_prof'),

# aluno 
    path('cadastrar/perfil_aluno/', Perfil_alunoCreate.as_view(), name='cadastrar-perfil_aluno'),
    path('editar/perfil_aluno/', Perfil_alunoUpdate.as_view(), name='editar-perfil_aluno'),
    path('excluir/perfil_aluno/', Perfil_alunoDelete.as_view(), name='excluir-perfil_aluno'),
    path('listar/perfil_aluno/', Perfil_alunoList.as_view(), name='listar-perfil_aluno'),

]
