from typing import List
from django.db import models
from django.db.models import fields
from django.shortcuts import render
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.list import ListView
from .models import Sigla, Horas, Materia, Atividade, Perfil_professor, Perfil_aluno
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from braces.views import GroupRequiredMixin

from django.shortcuts import get_object_or_404  

# views 

class siglaCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Sigla
    fields = ['nome']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastro de siglas'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

class horasCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Horas
    fields = ['sigla']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastro de horass'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

class MateriaCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Materia
    fields = ['nome', 'horas', 'sigla', 'professor']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastro de Materias'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

class AtividadeCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = ["Administrador", "Educador"]
    model = Atividade
    fields = ['descricao', 'materia', 'arquivo']
    template_name = 'cadastros/form-upload.html'
    success_url = reverse_lazy('listar-atividade')

    def form_valid(self, form):

        # Antes do super não foi criado o objeto nem salvo no banco
        form.instance.usuario = self.request.user

        url = super().form_valid(form)

        return url

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastro de atividade'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

class Perfil_professorCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Perfil_professor
    fields = ['nome', 'idade', 'titulacao']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastrar Perfil do Professor'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

class Perfil_alunoCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Perfil_aluno
    fields = ['nome', 'idade', 'horas']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Cadastrar Perfil do Aluno'
        context['botao'] = 'Cadastrar'
        context['cor'] = 'info'
        return context

# alterar

class AtividadeUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Atividade
    fields = ['descricao', 'materia', 'arquivo' ]
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('listar-atividade')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar atividade'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context

    def get_object(self, queryset=None):
        self.object = get_object_or_404(Atividade, pk=self.kwargs['pk'], usuario=self.request.user)
        return self.object

class siglaUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Sigla
    fields = ['nome']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar sigla'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context

class horasUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Horas
    fields = ['sigla']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar horas'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context

class MateriaUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Materia
    fields = ['nome', 'horas', 'sigla', 'professor']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar materia'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context

    def get_object(self, queryset=None):
        self.object = get_object_or_404(Materia, pk=self.kwargs['pk'], usuario=self.request.user)
        return self.object
        
class Perfil_professorUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Educador"
    model = Perfil_professor
    fields = ['nome', 'idade', 'titulacao']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_object(self, queryset=None):
        self.object = Perfil_professor.objects.get(professor=self.request.user)
        return self.object

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar Perfil Professor'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context


class Perfil_alunoUpdate(GroupRequiredMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('login')
    group_required = u"Alunos"
    model = Perfil_aluno
    fields = ['nome', 'idade', 'horas']
    template_name = 'cadastros/form.html'
    success_url = reverse_lazy('index')

    def get_object(self, queryset=None):
        self.object = Perfil_aluno.objects.get(aluno=self.request.user)
        return self.object

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Editar Perfil Aluno'
        context['botao'] = 'Salvar'
        context['cor'] = 'info'
        return context
#apagar

class AtividadeDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Atividade
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão de Atividade'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context

    def get_object(self, queryset=None):
        self.object = get_object_or_404(Atividade, pk=self.kwargs['pk'], usuario=self.request.user)
        return self.object
    
class siglaDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Sigla
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão de sigla'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context

class horasDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Horas
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão da horas'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context

class MateriaDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Materia
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão de Materia'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context

    def get_object(self, queryset=None):
        self.object = get_object_or_404(Materia, pk=self.kwargs['pk'], usuario=self.request.user)
        return self.object

class Perfil_professorDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Perfil_professor
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão do Perfil Professor'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context
    
class Perfil_alunoDelete(GroupRequiredMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('login')
    group_required = u"Administrador"
    model = Perfil_aluno
    template_name = 'cadastros/form-excluir.html'
    success_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = 'Exlusão do Perfil Aluno'
        context['botao'] = 'Excluir'
        context['cor'] = 'danger'
        return context


# listas 

class AtividadeList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Atividade
    template_name = 'cadastros/listas/atividade.html'

    # def get_queryset(self):
    #     self.object_list = Atividade.objects.filter(usuario=self.request.user)
    #     return self.object_list

class siglaList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Sigla
    template_name = 'cadastros/listas/sigla.html'

class horasList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Horas
    template_name = 'cadastros/listas/horas.html'

class MateriaList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Materia
    template_name = 'cadastros/listas/materia.html'

    def get_queryset(self):
        self.object_list = Materia.objects.filter(professor=self.request.user)
        return self.object_list

class Perfil_professorList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Perfil_professor
    template_name = 'cadastros/listas/perfil_prof.html'

class Perfil_alunoList(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    model = Perfil_aluno
    template_name = 'cadastros/listas/perfil_aluno.html'
